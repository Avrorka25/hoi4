version="1.19-v2fix.2-ru"
name="Road to 56 RP v2 (HOI4 1.19)"
tags={ "Alternative History" "Gameplay" }
picture="thumbnail.png"
supported_version="1.19.*"
replace_path="history/states"
replace_path="map/strategicregions"
