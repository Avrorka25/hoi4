Патч 1.19-rufix.2 накладывается на исходный мод или пакет rufix.1.
Если мод ещё не установлен, сначала скопируйте все исходные файлы в
Documents/Paradox Interactive/Hearts of Iron IV/mod/Road_to_56_RP.
Скопируйте папку Road_to_56_RP и внешний Road_to_56_RP.mod из патча
в папку mod с заменой файлов, включая оба файла событий.
Включите только одну RP-версию вместе с The Road to 56.
Прочитайте README_RU.md и CRASH_ANALYSIS_RU.md для проверки запуска.
