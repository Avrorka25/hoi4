version="1.19-rufix.2"
tags={
 "Utilities"
 "Gameplay"
 "Alternative History"
 "Map"
 "National Focuses"
 "Graphics"
 "Events"
}
dependencies={ "The Road to 56" }
name="The Road to 56 RP (RU fixes)"
picture="thumbnail.png"
supported_version="1.19.*"
